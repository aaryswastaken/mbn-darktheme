# Moodle Dark
Chrome Extension for Moodle Dark -- Work in Progress

Find it on the Chrome Web Store at https://chrome.google.com/webstore/detail/moodle-dark-lsu/fcejongbnjkbhbgncbjflhiknphgkclg

![image](https://user-images.githubusercontent.com/26977302/74184744-f0b60280-4c0c-11ea-96c7-db37fa21b98c.png)
